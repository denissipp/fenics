# fenics_sandbox
A repository to try and play with fenics

Notebooks currenlty supporting Google Colab:
- cylinder.ipynb 
